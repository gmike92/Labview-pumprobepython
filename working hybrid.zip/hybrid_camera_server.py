import numpy as np
import h5py
import time
import sys
import os
from datetime import datetime
from threading import Thread

# Try importing pyqtgraph
try:
    import pyqtgraph as pg
    from pyqtgraph.Qt import QtCore, QtWidgets
except ImportError:
    print("Error: pyqtgraph is not installed. Please install it with 'pip install pyqtgraph pyqt6'")
    sys.exit(1)

# Try importing pywin32 for LabVIEW ActiveX automation
try:
    import win32com.client
    import pythoncom
    HAS_WIN32COM = True
except ImportError:
    print("[WARN] pywin32 not installed. LabVIEW automation disabled. Install with: pip install pywin32")
    HAS_WIN32COM = False

# =============================================================================
# Configuration
# =============================================================================
NUM_FRAMES = 100
FRAME_HEIGHT = 128
FRAME_WIDTH = 128

# Path to the persistent Manager VI
DEFAULT_VI_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "Experiment_manager.vi"
)

# Command Enum values (must match LabVIEW enum)
CMD_IDLE = 0
CMD_INIT = 1
CMD_GETFRAME = 2
CMD_CLOSE = 3


# =============================================================================
# LabVIEW Manager Controller (Puppeteer Pattern)
# =============================================================================
class LabVIEWManager:
    """
    Controls the persistent Experiment_manager.vi via ActiveX.
    
    The Manager VI runs continuously with a While Loop + Case Structure.
    Python sends commands by setting the "Enum" control,
    then polls until the VI sets it back to "Idle" (0).
    
    Enum values:
        0 = Idle       (do nothing, wait)
        1 = Init       (open camera → returns to Idle)
        2 = Getframe   (continuous loop: acquire → T, DeltaT)
        3 = Close      (close camera → returns to Idle)
    
    Controls:
        N          (I32)  — number of frames per acquisition
        Acq Trigger (Bool) — acquisition trigger
        Stoplive   (Bool) — set True to exit Getframe loop → Idle
        End        (Bool) — stop the Manager VI after Close
    
    Indicators:
        T       — transmission data
        DeltaT  — delta T/T data
    """
    
    def __init__(self, vi_path: str = DEFAULT_VI_PATH):
        self.vi_path = vi_path
        self.lv = None
        self.vi = None
        self.is_running = False
    
    def start(self):
        """Launch LabVIEW, load Manager VI, and run it (non-blocking)."""
        if not HAS_WIN32COM:
            print("[ERROR] pywin32 not available")
            return False
        
        try:
            # Connect to or launch LabVIEW
            try:
                self.lv = win32com.client.GetActiveObject("LabVIEW.Application")
                print("[OK] Connected to existing LabVIEW instance")
            except Exception:
                self.lv = win32com.client.Dispatch("LabVIEW.Application")
                print("[OK] Launched new LabVIEW instance")
            
            # Load the Manager VI
            if not os.path.exists(self.vi_path):
                print(f"[ERROR] VI not found: {self.vi_path}")
                return False
            
            self.vi = self.lv.GetVIReference(self.vi_path)
            
            # Tell COM these are methods, not properties (late-binding fix)
            self.vi._FlagAsMethod("Run")
            self.vi._FlagAsMethod("Abort")
            self.vi._FlagAsMethod("SetControlValue")
            self.vi._FlagAsMethod("GetControlValue")
            
            self.vi.FPWinOpen = True
            print(f"[OK] Loaded: {os.path.basename(self.vi_path)}")
            
            # Run non-blocking — VI stays alive with its While Loop
            try:
                self.vi.Run(True)  # True = async (returns immediately)
                print("[OK] Manager VI started (async)")
            except Exception as run_err:
                print(f"[WARN] Run(False) failed: {run_err}")
                print("[INFO] Please click the Run button in LabVIEW manually.")
                print("[INFO] Then click 'Initialize Camera' in Python.")
            
            self.is_running = True
            return True
            
        except Exception as e:
            print(f"[ERROR] Failed to start Manager: {e}")
            return False
    
    def send_command(self, cmd, timeout=30.0):
        """
        Send a command and wait for the VI to return to Idle.
        
        Args:
            cmd: CMD_IDLE, CMD_INITIALIZE, CMD_ACQUIRE, or CMD_EXIT
            timeout: Max seconds to wait for completion
            
        Returns:
            True if command completed (returned to Idle), False on timeout
        """
        if not self.vi:
            print("[ERROR] Manager VI not loaded")
            return False
        
        try:
            self.vi.SetControlValue("Enum", cmd)
            
            # Poll until Enum returns to Idle
            waited = 0.0
            poll_interval = 0.05  # 50ms
            while waited < timeout:
                time.sleep(poll_interval)
                waited += poll_interval
                current = self.vi.GetControlValue("Enum")
                if current == CMD_IDLE:
                    return True
            
            print(f"[WARN] Command {cmd} timed out after {timeout}s")
            return False
            
        except Exception as e:
            print(f"[ERROR] send_command failed: {e}")
            return False
    
    def initialize_camera(self):
        """Send Init command (enum = 1). Camera opens and stays open."""
        print("[CMD] Init camera...")
        success = self.send_command(CMD_INIT, timeout=30.0)
        if success:
            print("[OK] Camera initialized")
        else:
            print("[ERROR] Camera initialization failed or timed out")
        return success
    
    def acquire_map(self, n_frames=100, acq_trigger=True):
        """
        Set parameters, send Getframe command, read result.
        
        Args:
            n_frames: Number of frames
            acq_trigger: Acquisition trigger boolean
            
        Returns:
            dict with 'T' and 'DeltaT' numpy arrays, or None
        """
        if not self.vi:
            return None
        
        try:
            # Set parameters before acquiring
            self.vi.SetControlValue("N", n_frames)
            self.vi.SetControlValue("Acq Trigger", acq_trigger)
            
            print(f"[CMD] Getframe (N={n_frames}, trigger={acq_trigger})...")
            
            # Send Getframe command and wait
            success = self.send_command(CMD_GETFRAME, timeout=60.0)
            if not success:
                print("[ERROR] Getframe timed out")
                return None
            
            # Read both results from VI
            result = {}
            t_data = self.vi.GetControlValue("T")
            dt_data = self.vi.GetControlValue("DeltaT")
            
            if t_data is not None:
                result['T'] = np.array(t_data)
            if dt_data is not None:
                result['DeltaT'] = np.array(dt_data)
            
            return result if result else None
            
        except Exception as e:
            print(f"[ERROR] acquire_map failed: {e}")
            return None
    
    def shutdown(self):
        """Close camera (enum=3), then set End=True to stop the Manager VI."""
        if not self.is_running or not self.vi:
            return
        
        try:
            # Step 1: Close camera
            print("[CMD] Closing camera...")
            self.vi.SetControlValue("Enum", CMD_CLOSE)
            
            # Poll for Idle
            waited = 0.0
            while waited < 15.0:
                time.sleep(0.1)
                waited += 0.1
                try:
                    if self.vi.GetControlValue("Enum") == CMD_IDLE:
                        break
                except Exception:
                    break
            
            # Step 2: End the Manager VI
            print("[CMD] Ending Manager VI...")
            self.vi.SetControlValue("end", True)
            time.sleep(1.0)
            
            self.is_running = False
            print("[OK] Manager VI stopped")
        except Exception as e:
            print(f"[WARN] Shutdown error: {e}")
        
        self.vi = None
        self.lv = None
    
    def close(self):
        """Clean up — send Exit if still running."""
        if self.is_running:
            self.shutdown()


# =============================================================================
# Main Window
# =============================================================================
class MainWindow(QtWidgets.QMainWindow):
    # Signals for thread-safe UI updates
    new_data_signal = QtCore.pyqtSignal(object)
    status_signal = QtCore.pyqtSignal(str)
    acq_finished_signal = QtCore.pyqtSignal()
    camera_connected_signal = QtCore.pyqtSignal(bool)
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Hybrid Camera Server")
        self.resize(900, 800)
        
        # Controller
        self.manager = LabVIEWManager()
        self.acquiring = False
        self.camera_initialized = False
        
        # Connect signals
        self.new_data_signal.connect(self.update_plot)
        self.status_signal.connect(self.update_status)
        self.acq_finished_signal.connect(self._on_acq_finished)
        self.camera_connected_signal.connect(self._on_camera_connected)
        
        # Central Layout
        central_widget = QtWidgets.QWidget()
        self.setCentralWidget(central_widget)
        layout = QtWidgets.QVBoxLayout(central_widget)
        
        # =====================================================================
        # Connection & Camera
        # =====================================================================
        hw_group = QtWidgets.QGroupBox("Camera (via Experiment_Manager.vi)")
        hw_layout = QtWidgets.QGridLayout(hw_group)
        layout.addWidget(hw_group)
        
        # Row 0: VI Path
        hw_layout.addWidget(QtWidgets.QLabel("Manager VI:"), 0, 0)
        self.vi_path_edit = QtWidgets.QLineEdit(DEFAULT_VI_PATH)
        hw_layout.addWidget(self.vi_path_edit, 0, 1, 1, 3)
        
        self.browse_vi_btn = QtWidgets.QPushButton("Browse...")
        self.browse_vi_btn.clicked.connect(self.browse_vi)
        hw_layout.addWidget(self.browse_vi_btn, 0, 4)
        
        # Row 1: Start Manager / Initialize Camera / Status
        self.start_mgr_btn = QtWidgets.QPushButton("▶ Start Manager")
        self.start_mgr_btn.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
        self.start_mgr_btn.clicked.connect(self.start_manager)
        hw_layout.addWidget(self.start_mgr_btn, 1, 0)
        
        self.init_cam_btn = QtWidgets.QPushButton("🔌 Initialize Camera")
        self.init_cam_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold;")
        self.init_cam_btn.clicked.connect(self.initialize_camera)
        self.init_cam_btn.setEnabled(False)
        hw_layout.addWidget(self.init_cam_btn, 1, 1)
        
        self.shutdown_btn = QtWidgets.QPushButton("⏹ Shutdown")
        self.shutdown_btn.setStyleSheet("background-color: #f44336; color: white; font-weight: bold;")
        self.shutdown_btn.clicked.connect(self.shutdown_manager)
        self.shutdown_btn.setEnabled(False)
        hw_layout.addWidget(self.shutdown_btn, 1, 2)
        
        self.hw_status_label = QtWidgets.QLabel("Status: Not Started")
        self.hw_status_label.setStyleSheet("color: red; font-weight: bold;")
        hw_layout.addWidget(self.hw_status_label, 1, 3, 1, 2)
        
        # =====================================================================
        # Acquisition Controls
        # =====================================================================
        acq_group = QtWidgets.QGroupBox("Acquisition")
        acq_layout = QtWidgets.QGridLayout(acq_group)
        layout.addWidget(acq_group)
        
        # Row 0: N, Mode, Invert Phase
        acq_layout.addWidget(QtWidgets.QLabel("Frames (N):"), 0, 0)
        self.frames_spinbox = QtWidgets.QSpinBox()
        self.frames_spinbox.setRange(2, 10000)
        self.frames_spinbox.setValue(NUM_FRAMES)
        self.frames_spinbox.setSingleStep(2)
        acq_layout.addWidget(self.frames_spinbox, 0, 1)
        
        acq_layout.addWidget(QtWidgets.QLabel("Mode:"), 0, 2)
        self.mode_combo = QtWidgets.QComboBox()
        self.mode_combo.addItems(["ΔT/T (dT)", "Transmission (T)"])
        self.mode_combo.currentIndexChanged.connect(self.change_mode)
        acq_layout.addWidget(self.mode_combo, 0, 3)
        
        self.invert_chk = QtWidgets.QCheckBox("Invert Phase")
        self.invert_chk.setToolTip("Swap On/Off phase assignment (XOR in LabVIEW)")
        acq_layout.addWidget(self.invert_chk, 0, 4)
        
        # Row 1: Acquire + Stop
        self.acquire_btn = QtWidgets.QPushButton(" ▶  ACQUIRE ")
        self.acquire_btn.setStyleSheet(
            "background-color: #2196F3; color: white; font-weight: bold; "
            "font-size: 14px; padding: 8px 20px;"
        )
        self.acquire_btn.clicked.connect(self.start_acquisition)
        self.acquire_btn.setEnabled(False)
        acq_layout.addWidget(self.acquire_btn, 1, 0, 1, 2)
        
        self.stop_acq_btn = QtWidgets.QPushButton("■ STOP")
        self.stop_acq_btn.setStyleSheet(
            "background-color: #FF9800; color: white; font-weight: bold; "
            "font-size: 14px; padding: 8px 20px;"
        )
        self.stop_acq_btn.clicked.connect(self.stop_acquisition)
        self.stop_acq_btn.setEnabled(False)
        acq_layout.addWidget(self.stop_acq_btn, 1, 2, 1, 2)
        
        self.batch_label = QtWidgets.QLabel("Batches: 0")
        acq_layout.addWidget(self.batch_label, 1, 4)
        
        # =====================================================================
        # Status Bar
        # =====================================================================
        self.status_label = QtWidgets.QLabel("Status: Ready")
        layout.addWidget(self.status_label)
        
        # =====================================================================
        # Plotting Area
        # =====================================================================
        self.plot_widget = pg.GraphicsLayoutWidget()
        layout.addWidget(self.plot_widget)
        
        self.img_view = self.plot_widget.addPlot(title="Camera Feed")
        self.img_item = pg.ImageItem()
        self.img_view.addItem(self.img_item)
        
        self.hist = pg.HistogramLUTItem()
        self.hist.setImageItem(self.img_item)
        self.plot_widget.addItem(self.hist)
        
        # Set initial colormap
        self.change_mode(0)
    
    # =========================================================================
    # Manager Control Slots
    # =========================================================================
    def browse_vi(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Select Manager VI", "", "LabVIEW VI (*.vi);;All Files (*)"
        )
        if path:
            self.vi_path_edit.setText(path)
    
    def start_manager(self):
        """Start the persistent Manager VI (non-blocking)."""
        if not HAS_WIN32COM:
            self.update_status("ERROR: pywin32 not installed")
            return
        
        self.hw_status_label.setText("Status: Starting LabVIEW...")
        self.hw_status_label.setStyleSheet("color: orange; font-weight: bold;")
        QtWidgets.QApplication.processEvents()
        
        self.manager.vi_path = self.vi_path_edit.text()
        
        if self.manager.start():
            self.hw_status_label.setText("Status: Manager Running (Camera not init)")
            self.hw_status_label.setStyleSheet("color: #2196F3; font-weight: bold;")
            self.start_mgr_btn.setEnabled(False)
            self.init_cam_btn.setEnabled(True)
            self.shutdown_btn.setEnabled(True)
            self.vi_path_edit.setEnabled(False)
            self.browse_vi_btn.setEnabled(False)
        else:
            self.hw_status_label.setText("Status: FAILED to start")
            self.hw_status_label.setStyleSheet("color: red; font-weight: bold;")
    
    def initialize_camera(self):
        """Send Init command to Manager VI (main thread, with processEvents)."""
        self.hw_status_label.setText("Status: Initializing camera...")
        self.hw_status_label.setStyleSheet("color: orange; font-weight: bold;")
        QtWidgets.QApplication.processEvents()
        
        vi = self.manager.vi
        
        # Diagnostic: test each control name individually
        test_controls = [
            ("Enum", CMD_INIT),
            ("N", 100),
            ("Acq Trigger", True),
            ("Stoplive", False),
        ]
        for name, val in test_controls:
            try:
                vi.SetControlValue(name, val)
                print(f"  [OK] SetControlValue(\"{name}\", {val})")
            except Exception as e:
                print(f"  [FAIL] SetControlValue(\"{name}\", {val}) → {e}")
        
        # Test reading indicators
        test_indicators = ["Enum", "T", "DeltaT"]
        for name in test_indicators:
            try:
                val = vi.GetControlValue(name)
                print(f"  [OK] GetControlValue(\"{name}\") = {val}")
            except Exception as e:
                print(f"  [FAIL] GetControlValue(\"{name}\") → {e}")
        
        # If Command was set successfully, poll for Idle
        try:
            waited = 0.0
            while waited < 30.0:
                time.sleep(0.1)
                waited += 0.1
                QtWidgets.QApplication.processEvents()
                try:
                    if vi.GetControlValue("Enum") == CMD_IDLE:
                        self._on_camera_connected(True)
                        return
                except Exception:
                    pass
            
            self._on_camera_connected(False)
        except Exception as e:
            print(f"[ERROR] Init: {e}")
            self._on_camera_connected(False)
    
    def _on_camera_connected(self, success):
        """Thread-safe UI update after camera init."""
        if success:
            self.camera_initialized = True
            self.hw_status_label.setText("Status: Camera Ready ✓")
            self.hw_status_label.setStyleSheet("color: green; font-weight: bold;")
            self.init_cam_btn.setEnabled(False)
            self.acquire_btn.setEnabled(True)
        else:
            self.hw_status_label.setText("Status: Init FAILED")
            self.hw_status_label.setStyleSheet("color: red; font-weight: bold;")
    
    def shutdown_manager(self):
        """Send Exit command and clean up."""
        self.acquiring = False
        self.manager.shutdown()
        self.camera_initialized = False
        self.hw_status_label.setText("Status: Not Started")
        self.hw_status_label.setStyleSheet("color: red; font-weight: bold;")
        self.start_mgr_btn.setEnabled(True)
        self.init_cam_btn.setEnabled(False)
        self.shutdown_btn.setEnabled(False)
        self.acquire_btn.setEnabled(False)
        self.stop_acq_btn.setEnabled(False)
        self.vi_path_edit.setEnabled(True)
        self.browse_vi_btn.setEnabled(True)
    
    # =========================================================================
    # Acquisition Slots
    # =========================================================================
    def start_acquisition(self):
        """Start continuous live view — send Getframe once, LabVIEW loops internally."""
        self.acquiring = True
        self.batch_count = 0
        self.acquire_btn.setEnabled(False)
        self.stop_acq_btn.setEnabled(True)
        
        vi = self.manager.vi
        n = self.frames_spinbox.value()
        
        try:
            # Set parameters
            vi.SetControlValue("N", n)
            vi.SetControlValue("Acq Trigger", True)
            vi.SetControlValue("Stoplive", False)
            
            # Send Getframe ONCE — LabVIEW loops internally
            vi.SetControlValue("Enum", CMD_GETFRAME)
            
            self.update_status(f"Live view started (N={n})...")
            
            # Start polling timer to read latest data from VI
            self._poll_timer = QtCore.QTimer()
            self._poll_timer.timeout.connect(self._poll_live_data)
            self._poll_timer.start(50)  # Read every 50ms
            
        except Exception as e:
            self.update_status(f"Acquire error: {e}")
            self._on_acq_finished()
    
    def _poll_live_data(self):
        """Read the latest T/DeltaT from the continuously-running VI."""
        if not self.acquiring:
            self._poll_timer.stop()
            return
        
        mode = "dt" if self.mode_combo.currentIndex() == 0 else "t"
        indicator = "DeltaT" if mode == "dt" else "T"
        
        try:
            data = self.manager.vi.GetControlValue(indicator)
            if data is not None:
                img = np.array(data)
                self.batch_count += 1
                self.update_plot(img)
                self.update_status(
                    f"Live #{self.batch_count} ({img.shape[0]}×{img.shape[1]}, {indicator})"
                )
        except Exception as e:
            self.update_status(f"Read error: {e}")
    
    def _on_acq_finished(self):
        """UI reset after acquisition ends."""
        self.acquire_btn.setEnabled(True)
        self.stop_acq_btn.setEnabled(False)
    
    def stop_acquisition(self):
        """Stop live view — set Stoplive=True, LabVIEW exits Getframe loop → Idle."""
        self.acquiring = False
        
        if hasattr(self, '_poll_timer'):
            self._poll_timer.stop()
        
        try:
            self.manager.vi.SetControlValue("Stoplive", True)
            self.update_status("Stopping live view...")
            
            # Wait for LabVIEW to return to Idle
            waited = 0.0
            while waited < 10.0:
                time.sleep(0.1)
                waited += 0.1
                QtWidgets.QApplication.processEvents()
                try:
                    if self.manager.vi.GetControlValue("Enum") == CMD_IDLE:
                        break
                except Exception:
                    break
            
            self.update_status("Live view stopped.")
        except Exception as e:
            self.update_status(f"Stop error: {e}")
        
        self._on_acq_finished()
    
    def save_data(self, img, mode):
        """Save result to HDF5."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"scan_data_{timestamp}.h5"
        try:
            with h5py.File(filename, 'w') as f:
                f.create_dataset("image", data=img)
                f.attrs['mode'] = mode
        except Exception as e:
            print(f"Save error: {e}")
    
    # =========================================================================
    # Display Slots
    # =========================================================================
    def change_mode(self, index):
        if index == 0:  # DT mode — Blue → White (zero) → Red
            pos = np.array([0.0, 0.25, 0.5, 0.75, 1.0])
            color = np.array([
                [0,   0,   180, 255],   # dark blue
                [100, 150, 255, 255],   # light blue
                [255, 255, 255, 255],   # white (zero)
                [255, 150, 100, 255],   # light red
                [180, 0,   0,   255],   # dark red
            ], dtype=np.ubyte)
            cmap = pg.ColorMap(pos, color)
            self.img_item.setLookupTable(cmap.getLookupTable(0.0, 1.0, 256))
        else:  # T mode — Magma (or jet fallback)
            try:
                self.img_item.setLookupTable(pg.colormap.get('magma').getLookupTable())
            except Exception:
                try:
                    self.img_item.setLookupTable(pg.colormap.get('CET-L8').getLookupTable())
                except Exception:
                    # Manual jet-like fallback
                    pos = np.array([0.0, 0.25, 0.5, 0.75, 1.0])
                    color = np.array([
                        [0, 0, 128, 255], [0, 255, 255, 255], [0, 255, 0, 255],
                        [255, 255, 0, 255], [255, 0, 0, 255]
                    ], dtype=np.ubyte)
                    cmap = pg.ColorMap(pos, color)
                    self.img_item.setLookupTable(cmap.getLookupTable(0.0, 1.0, 256))
        
    def update_plot(self, img_data):
        self.img_item.setImage(img_data.T)
        
    def update_status(self, msg):
        self.status_label.setText(f"Status: {msg}")
        
    def closeEvent(self, event):
        self.acquiring = False
        self.manager.close()
        event.accept()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

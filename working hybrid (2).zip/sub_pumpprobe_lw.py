"""
Pump-Probe Delay Scan — scans Thorlabs delay stage while acquiring
via LabVIEW Experiment_manager.vi.

For each scan point:
  1. Move delay stage → poll position stability (3 reads within 1µm)
  2. Settle 50ms for optical vibrations
  3. Trigger LabVIEW: Enum=Measure (single-shot) → poll Idle → read DeltaT
  4. CSV append (incremental safety save)
  5. Update live ΔT/T vs Delay plot → next point

Usage:
    from sub_pumpprobe_lw import PumpProbeScanWindow
    window = PumpProbeScanWindow(labview_manager, delay_stage)
    window.show()
"""

import csv
import numpy as np
from datetime import datetime

try:
    import pyqtgraph as pg
    from pyqtgraph.Qt import QtCore, QtWidgets
except ImportError:
    raise ImportError("pyqtgraph required: pip install pyqtgraph pyqt6")

from labview_manager import LabVIEWManager, CMD_IDLE, CMD_MEASURE

# Physics
SPEED_OF_LIGHT_MM_FS = 0.000299792458
GLOBAL_ZERO_POS_MM = 140.0


class PumpProbeScanWindow(QtWidgets.QWidget):
    """
    Pump-probe delay scan using Thorlabs stage + LabVIEW camera.
    """
    
    def __init__(self, manager: LabVIEWManager, delay_stage, live_window=None, parent=None):
        super().__init__(parent)
        self.manager = manager
        self.delay_stage = delay_stage
        self.live_window = live_window  # for ROI / pixel signal extraction
        
        # Scan state
        self.scanning = False
        self.scan_points_fs = []
        self.scan_delays = []
        self.scan_signals = []
        self.scan_index = 0
        self.scan_csv_path = None
        self.roi_datacube = []    # list of 2D ROI slices per point
        
        self.setWindowTitle("Pump-Probe Delay Scan (LabVIEW)")
        self.resize(900, 800)
        self._setup_ui()
    
    def _setup_ui(self):
        main_layout = QtWidgets.QHBoxLayout(self)

        # ====== Left Panel: Scan Controls ======
        left_panel = QtWidgets.QWidget()
        left_panel.setMaximumWidth(320)
        left_layout = QtWidgets.QVBoxLayout(left_panel)

        # Title
        title = QtWidgets.QLabel("Pump-Probe Delay Scan")
        title.setStyleSheet(
            "font-size: 15px; font-weight: bold; color: #4CAF50; padding: 5px;"
        )
        title.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        left_layout.addWidget(title)

        # Zero position
        zero_group = QtWidgets.QGroupBox("Zero Position (t=0)")
        zero_layout = QtWidgets.QHBoxLayout(zero_group)
        zero_layout.addWidget(QtWidgets.QLabel("Position (mm):"))
        self.zero_spin = QtWidgets.QDoubleSpinBox()
        self.zero_spin.setRange(0, 300)
        self.zero_spin.setDecimals(3)
        self.zero_spin.setValue(GLOBAL_ZERO_POS_MM)
        zero_layout.addWidget(self.zero_spin)
        left_layout.addWidget(zero_group)

        # 3 Intervals
        interval_configs = [
            ("Interval 1 (Fine)", -1000, 0, 50),
            ("Interval 2 (Mid)", 0, 10000, 100),
            ("Interval 3 (Coarse)", 10000, 100000, 1000),
        ]
        self.interval_spins = []

        for label, s_def, e_def, st_def in interval_configs:
            grp = QtWidgets.QGroupBox(label)
            gl = QtWidgets.QGridLayout(grp)

            gl.addWidget(QtWidgets.QLabel("Start (fs):"), 0, 0)
            sp_s = QtWidgets.QDoubleSpinBox()
            sp_s.setRange(-1e6, 1e6)
            sp_s.setValue(s_def)
            gl.addWidget(sp_s, 0, 1)

            gl.addWidget(QtWidgets.QLabel("End (fs):"), 0, 2)
            sp_e = QtWidgets.QDoubleSpinBox()
            sp_e.setRange(-1e6, 1e6)
            sp_e.setValue(e_def)
            gl.addWidget(sp_e, 0, 3)

            gl.addWidget(QtWidgets.QLabel("Step (fs):"), 1, 0)
            sp_st = QtWidgets.QDoubleSpinBox()
            sp_st.setRange(1, 1e6)
            sp_st.setValue(st_def)
            gl.addWidget(sp_st, 1, 1)

            self.interval_spins.append((sp_s, sp_e, sp_st))
            left_layout.addWidget(grp)

        # Acquisition settings
        acq_group = QtWidgets.QGroupBox("Acquisition")
        acq_layout = QtWidgets.QGridLayout(acq_group)

        acq_layout.addWidget(QtWidgets.QLabel("Frames/point:"), 0, 0)
        self.frames_spin = QtWidgets.QSpinBox()
        self.frames_spin.setRange(2, 10000)
        self.frames_spin.setValue(100)
        acq_layout.addWidget(self.frames_spin, 0, 1)

        self.points_label = QtWidgets.QLabel("Points: --")
        self.points_label.setStyleSheet("font-weight: bold;")
        acq_layout.addWidget(self.points_label, 1, 0, 1, 2)
        left_layout.addWidget(acq_group)

        # Start / Stop buttons
        btn_row = QtWidgets.QHBoxLayout()

        self.start_btn = QtWidgets.QPushButton("START SCAN")
        self.start_btn.setStyleSheet(
            "background-color: #4CAF50; color: white; font-weight: bold; "
            "font-size: 14px; padding: 12px; border-radius: 6px;"
        )
        self.start_btn.clicked.connect(self.start_scan)
        btn_row.addWidget(self.start_btn)

        self.stop_btn = QtWidgets.QPushButton("STOP")
        self.stop_btn.setStyleSheet(
            "background-color: #f44336; color: white; font-weight: bold; "
            "font-size: 14px; padding: 12px; border-radius: 6px;"
        )
        self.stop_btn.clicked.connect(self.stop_scan)
        self.stop_btn.setEnabled(False)
        btn_row.addWidget(self.stop_btn)
        left_layout.addLayout(btn_row)

        # Progress + Status
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        left_layout.addWidget(self.progress)

        self.status_label = QtWidgets.QLabel("Status: Ready")
        self.status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")
        left_layout.addWidget(self.status_label)

        left_layout.addStretch()
        main_layout.addWidget(left_panel)

        # ====== Middle Panel: Delay Stage ======
        stage_panel = QtWidgets.QWidget()
        stage_panel.setMaximumWidth(220)
        stage_layout = QtWidgets.QVBoxLayout(stage_panel)

        stage_title = QtWidgets.QLabel("Translation Stage")
        stage_title.setStyleSheet(
            "font-size: 13px; font-weight: bold; color: #2196F3;"
        )
        stage_title.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        stage_layout.addWidget(stage_title)

        # Position display
        pos_group = QtWidgets.QGroupBox("Position")
        pos_layout = QtWidgets.QGridLayout(pos_group)

        pos_layout.addWidget(QtWidgets.QLabel("Actual (mm):"), 0, 0)
        self.stage_label = QtWidgets.QLabel("---.---")
        self.stage_label.setStyleSheet(
            "font-weight: bold; font-size: 16px; color: #2196F3;"
        )
        pos_layout.addWidget(self.stage_label, 0, 1)

        pos_layout.addWidget(QtWidgets.QLabel("Actual (fs):"), 1, 0)
        self.lbl_stage_fs = QtWidgets.QLabel("------")
        self.lbl_stage_fs.setStyleSheet(
            "font-weight: bold; font-size: 16px; color: #9C27B0;"
        )
        pos_layout.addWidget(self.lbl_stage_fs, 1, 1)

        stage_layout.addWidget(pos_group)

        # Absolute move
        abs_group = QtWidgets.QGroupBox("Absolute Move")
        abs_layout = QtWidgets.QGridLayout(abs_group)

        abs_layout.addWidget(QtWidgets.QLabel("Position (mm):"), 0, 0)
        self.spin_abs_mm = QtWidgets.QDoubleSpinBox()
        self.spin_abs_mm.setRange(0.0, 300.0)
        self.spin_abs_mm.setValue(GLOBAL_ZERO_POS_MM)
        self.spin_abs_mm.setDecimals(3)
        self.spin_abs_mm.setSingleStep(0.01)
        abs_layout.addWidget(self.spin_abs_mm, 0, 1)

        self.btn_go_abs = QtWidgets.QPushButton("Go")
        self.btn_go_abs.setStyleSheet(
            "background-color: #FF9800; color: white; font-weight: bold; padding: 8px;"
        )
        self.btn_go_abs.clicked.connect(self._move_absolute)
        abs_layout.addWidget(self.btn_go_abs, 1, 0, 1, 2)

        stage_layout.addWidget(abs_group)

        # Relative step buttons
        step_group = QtWidgets.QGroupBox("Relative Steps")
        step_grid = QtWidgets.QGridLayout(step_group)

        steps_neg = [("-10 ps", -10000), ("-1 ps", -1000), ("-100 fs", -100)]
        for col, (label, fs) in enumerate(steps_neg):
            btn = QtWidgets.QPushButton(label)
            btn.setStyleSheet("padding: 6px;")
            btn.clicked.connect(lambda checked, d=fs: self._move_relative_fs(d))
            step_grid.addWidget(btn, 0, col)

        steps_pos = [("+100 fs", 100), ("+1 ps", 1000), ("+10 ps", 10000)]
        for col, (label, fs) in enumerate(steps_pos):
            btn = QtWidgets.QPushButton(label)
            btn.setStyleSheet("padding: 6px;")
            btn.clicked.connect(lambda checked, d=fs: self._move_relative_fs(d))
            step_grid.addWidget(btn, 1, col)

        stage_layout.addWidget(step_group)

        # Stage connection status
        self.lbl_stage_status = QtWidgets.QLabel("Not connected")
        self.lbl_stage_status.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.lbl_stage_status.setStyleSheet("color: #888;")
        stage_layout.addWidget(self.lbl_stage_status)

        stage_layout.addStretch()
        main_layout.addWidget(stage_panel)

        # ====== Right Panel: Display ======
        display_panel = QtWidgets.QWidget()
        display_layout = QtWidgets.QVBoxLayout(display_panel)

        # Vertical splitter: Camera frame on top, scan plot on bottom
        splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Vertical)

        # Camera frame
        cam_widget = pg.GraphicsLayoutWidget()
        self.img_view = cam_widget.addPlot(title="Last Acquired Frame (DeltaT/T)")
        self.img_item = pg.ImageItem()
        self.img_view.addItem(self.img_item)

        self.hist = pg.HistogramLUTItem()
        self.hist.setImageItem(self.img_item)
        cam_widget.addItem(self.hist)

        # DT colormap
        pos = np.array([0.0, 0.25, 0.5, 0.75, 1.0])
        color = np.array([
            [0, 0, 180, 255], [100, 150, 255, 255],
            [255, 255, 255, 255],
            [255, 150, 100, 255], [180, 0, 0, 255]
        ], dtype=np.ubyte)
        cmap = pg.ColorMap(pos, color)
        self.img_item.setLookupTable(cmap.getLookupTable(0.0, 1.0, 256))

        splitter.addWidget(cam_widget)

        # Scan plot
        self.scan_plot = pg.PlotWidget(
            title="DeltaT/T vs Delay",
            labels={'left': 'DeltaT/T (mean)', 'bottom': 'Delay (fs)'}
        )
        self.scan_plot.showGrid(x=True, y=True, alpha=0.3)
        self.scan_curve = self.scan_plot.plot(
            pen=pg.mkPen('#2196F3', width=2), symbol='o', symbolSize=4,
            symbolBrush='#2196F3'
        )
        splitter.addWidget(self.scan_plot)

        splitter.setSizes([400, 300])
        display_layout.addWidget(splitter)

        main_layout.addWidget(display_panel, stretch=1)

        # Stage position update timer
        self._stage_timer = QtCore.QTimer()
        self._stage_timer.timeout.connect(self._update_stage_display)
        self._stage_timer.start(500)
    
    # =========================================================================
    # Signal Extraction (ROI or Pixel from Live View)
    # =========================================================================
    
    def _extract(self, img):
        """Extract signal using Live View ROI/pixel selection, or full-image mean."""
        if self.live_window is not None:
            try:
                return self.live_window.extract_signal(img)
            except Exception:
                pass
        return float(np.nanmean(img))
    
    def _extract_roi(self, img):
        """Extract the full ROI region from a 2D image (no averaging)."""
        if img.ndim == 1:
            side = int(np.sqrt(img.size))
            if side * side == img.size:
                img = img.reshape(side, side)
            else:
                return img.reshape(1, -1)
        if self.live_window is not None:
            bounds = self.live_window.get_roi_bounds()
            if bounds:
                r0, r1, c0, c1 = bounds
                h, w = img.shape
                r0, r1 = max(0, min(r0, h)), max(1, min(r1, h))
                c0, c1 = max(0, min(c0, w)), max(1, min(c1, w))
                return img[r0:r1, c0:c1].copy()
        return img.copy()
    
    # =========================================================================
    # Unit Conversions
    # =========================================================================
    
    def _fs_to_mm(self, time_fs):
        return time_fs * SPEED_OF_LIGHT_MM_FS / 2.0
    
    def _mm_to_fs(self, distance_mm):
        return distance_mm * 2.0 / SPEED_OF_LIGHT_MM_FS
    
    # =========================================================================
    # Stage Control (middle panel)
    # =========================================================================
    
    def _update_stage_display(self):
        """Periodic stage position update."""
        if self.delay_stage and self.delay_stage.is_connected:
            try:
                pos_mm = self.delay_stage.get_position()
                self.stage_label.setText(f"{pos_mm:.3f}")
                delay_fs = (pos_mm - self.zero_spin.value()) / SPEED_OF_LIGHT_MM_FS * 2.0
                self.lbl_stage_fs.setText(f"{delay_fs:.0f}")
                self.lbl_stage_status.setText("Connected")
                self.lbl_stage_status.setStyleSheet("color: #4CAF50; font-weight: bold;")
            except Exception:
                self.stage_label.setText("err")
                self.lbl_stage_fs.setText("err")
        else:
            self.lbl_stage_status.setText("Not connected")
            self.lbl_stage_status.setStyleSheet("color: #888;")
    
    def _move_absolute(self):
        if not self.delay_stage or not self.delay_stage.is_connected:
            self.status_label.setText("Status: Stage not connected!")
            return
        target = self.spin_abs_mm.value()
        self.status_label.setText(f"Status: Moving to {target:.3f} mm...")
        self.btn_go_abs.setEnabled(False)
        import threading
        def do_move():
            self.delay_stage.move_to(target)
        threading.Thread(target=do_move, daemon=True).start()
        QtCore.QTimer.singleShot(1000, lambda: self.btn_go_abs.setEnabled(True))
        QtCore.QTimer.singleShot(1000, lambda: self.status_label.setText("Status: Ready"))
    
    def _move_relative_fs(self, delta_fs):
        if not self.delay_stage or not self.delay_stage.is_connected:
            self.status_label.setText("Status: Stage not connected!")
            return
        delta_mm = self._fs_to_mm(delta_fs)
        self.status_label.setText(f"Status: Step {delta_fs:+.0f} fs ({delta_mm:+.4f} mm)...")
        import threading
        def do_move():
            self.delay_stage.move_relative(delta_mm)
        threading.Thread(target=do_move, daemon=True).start()
        QtCore.QTimer.singleShot(500, lambda: self.status_label.setText("Status: Ready"))
    
    # =========================================================================
    # Scan Point Generation
    # =========================================================================
    
    def _generate_scan_points(self):
        """Generate scan positions from 3 intervals."""
        points = []
        for start_spin, end_spin, step_spin in self.interval_spins:
            s, e, st = start_spin.value(), end_spin.value(), step_spin.value()
            if s < e and st > 0:
                pts = np.arange(s, e, st)
                points.extend(pts.tolist())
        # Add final endpoint
        if self.interval_spins:
            points.append(self.interval_spins[-1][1].value())
        return np.array(points)
    
    # =========================================================================
    # Scan Control
    # =========================================================================
    
    def start_scan(self):
        """Start pump-probe delay scan."""
        if self.delay_stage is None or not self.delay_stage.is_connected:
            self.status_label.setText("Status: Connect delay stage first!")
            return
        if not self.manager.camera_initialized:
            self.status_label.setText("Status: Initialize camera first!")
            return
        
        # Generate scan points
        self.scan_points_fs = self._generate_scan_points()
        if len(self.scan_points_fs) == 0:
            self.status_label.setText("Status: No scan points! Check intervals.")
            return
        
        # Reset state
        self.scan_delays = []
        self.scan_signals = []
        self.scan_index = 0
        self.scanning = True
        self.scan_curve.setData([], [])
        
        # CSV for incremental saving
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.scan_csv_path = f"pumpprobe_{timestamp}.csv"
        with open(self.scan_csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["delay_fs", "pos_mm", "signal_dT_T"])
        
        # UI
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.progress.setValue(0)
        
        n_pts = len(self.scan_points_fs)
        self.points_label.setText(f"Points: 0/{n_pts}")
        self.status_label.setText(
            f"Status: Scanning {n_pts} points, "
            f"{self.scan_points_fs[0]:.0f} to {self.scan_points_fs[-1]:.0f} fs"
        )
        print(f"[SCAN] Starting {n_pts}-point scan")
        
        # Begin
        QtCore.QTimer.singleShot(100, self._move_stage)
    
    def _move_stage(self):
        """Move stage to next scan point."""
        if not self.scanning or self.scan_index >= len(self.scan_points_fs):
            self._scan_complete()
            return
        
        delay_fs = self.scan_points_fs[self.scan_index]
        zero_mm = self.zero_spin.value()
        target_mm = zero_mm + self._fs_to_mm(delay_fs)
        
        self.status_label.setText(
            f"Status: Point {self.scan_index+1}/{len(self.scan_points_fs)}: "
            f"{delay_fs:.0f} fs → {target_mm:.4f} mm"
        )
        self.stage_label.setText(f"Stage: → {target_mm:.3f} mm")
        
        # Non-blocking move
        self.delay_stage.move_to(target_mm, wait=False)
        
        # Poll for position stability
        self._poll_count = 0
        self._last_pos = None
        self._stable = 0
        self._poll_timer = QtCore.QTimer()
        self._poll_timer.timeout.connect(self._poll_stage)
        self._poll_timer.start(100)
    
    def _poll_stage(self):
        """Poll stage position until stable → trigger acquire."""
        if not self.scanning:
            self._poll_timer.stop()
            return
        
        self._poll_count += 1
        if self._poll_count > 600:  # 60s timeout
            self._poll_timer.stop()
            self.status_label.setText("Status: WARNING — Stage timeout, skipping")
            self.scan_index += 1
            QtCore.QTimer.singleShot(100, self._move_stage)
            return
        
        pos = self.delay_stage.get_position()
        self.stage_label.setText(f"Stage: {pos:.4f} mm")
        
        # 3 consecutive reads within 1µm = stable
        if self._last_pos is not None:
            if abs(pos - self._last_pos) < 0.001:
                self._stable += 1
                if self._stable >= 3:
                    self._poll_timer.stop()
                    # Settle for vibrations
                    QtCore.QTimer.singleShot(50, self._trigger_acquire)
                    return
            else:
                self._stable = 0
        
        self._last_pos = pos
    
    def _trigger_acquire(self):
        """Trigger one LabVIEW acquisition after stage settled."""
        if not self.scanning:
            return
        
        vi = self.manager.vi
        n = self.frames_spin.value()
        
        try:
            vi.SetControlValue("N", n)
            vi.SetControlValue("Acq Trigger", True)
            # Use Measure (single-shot) — acquires once then returns to Idle
            vi.SetControlValue("Enum", CMD_MEASURE)
            
            # Poll for Idle (single-shot acquire)
            self._acq_timer = QtCore.QTimer()
            self._acq_timer.timeout.connect(self._poll_acquire)
            self._acq_waited = 0.0
            self._acq_timer.start(50)
            
        except Exception as e:
            self.status_label.setText(f"Status: Acquire error — {e}")
            self.scan_index += 1
            QtCore.QTimer.singleShot(100, self._move_stage)
    
    def _poll_acquire(self):
        """Poll LabVIEW until Enum == Idle → read result."""
        if not self.scanning:
            self._acq_timer.stop()
            return
        
        self._acq_waited += 0.05
        if self._acq_waited > 60.0:
            self._acq_timer.stop()
            self.status_label.setText("Status: WARNING — Acquire timeout")
            self.scan_index += 1
            QtCore.QTimer.singleShot(100, self._move_stage)
            return
        
        try:
            if self.manager.vi.GetControlValue("Enum") != CMD_IDLE:
                return  # Still acquiring
        except Exception:
            return
        
        # Done — read result
        self._acq_timer.stop()
        delay_fs = self.scan_points_fs[self.scan_index]
        
        try:
            odd_data = self.manager.vi.GetControlValue("Odd")
            even_data = self.manager.vi.GetControlValue("Even")
            if odd_data is not None and even_data is not None:
                odd = np.array(odd_data, dtype=float)
                even = np.array(even_data, dtype=float)
                img = (even - odd) / np.where(np.abs(odd) > 1e-10, odd, 1e-10)
                
                # Skip empty data
                if img.size == 0:
                    print(f"[SCAN] Empty data at point {self.scan_index+1}")
                    self.scan_index += 1
                    QtCore.QTimer.singleShot(50, self._move_stage)
                    return
                if img.ndim == 1:
                    side = int(np.sqrt(img.size))
                    if side * side == img.size:
                        img = img.reshape(side, side)
                
                if img.ndim == 2:
                    self.img_item.setImage(img.T)
                
                signal = self._extract(img)
                roi_slice = self._extract_roi(img)
                self.roi_datacube.append(roi_slice)
                
                self.scan_delays.append(delay_fs)
                self.scan_signals.append(signal)
                self.scan_curve.setData(self.scan_delays, self.scan_signals)
                
                # CSV save
                actual_mm = self.delay_stage.get_position()
                with open(self.scan_csv_path, 'a', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow([f"{delay_fs:.2f}", f"{actual_mm:.4f}", f"{signal:.8e}"])
                
                print(f"[SCAN] Point {self.scan_index+1}: {delay_fs:.0f} fs = {signal:.4e}")
            else:
                print(f"[SCAN] No data at point {self.scan_index+1}")
                
        except Exception as e:
            print(f"[SCAN] Read error: {e}")
        
        # Update progress
        self.scan_index += 1
        pct = int(100 * self.scan_index / len(self.scan_points_fs))
        self.progress.setValue(pct)
        self.points_label.setText(
            f"Points: {self.scan_index}/{len(self.scan_points_fs)}"
        )
        
        QtCore.QTimer.singleShot(50, self._move_stage)
    
    def _scan_complete(self):
        """Save final data and reset UI."""
        self.scanning = False
        
        if self.scan_delays:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            npz_path = f"pumpprobe_{timestamp}_final.npz"
            np.savez(
                npz_path,
                delays_fs=np.array(self.scan_delays),
                signals=np.array(self.scan_signals),
                zero_mm=self.zero_spin.value(),
                frames_per_point=self.frames_spin.value(),
                roi_datacube=np.array(self.roi_datacube) if self.roi_datacube else np.array([])
            )
            self.status_label.setText(
                f"Status: Scan complete! {len(self.scan_delays)} points → {npz_path}"
            )
            print(f"[SCAN] Final data: {npz_path}")
        else:
            self.status_label.setText("Status: Scan complete (no data)")
        
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
    
    def stop_scan(self):
        """Emergency stop."""
        print("[SCAN] STOP requested")
        self.scanning = False
        
        if hasattr(self, '_poll_timer'):
            self._poll_timer.stop()
        if hasattr(self, '_acq_timer'):
            self._acq_timer.stop()
        
        self._scan_complete()
    
    def closeEvent(self, event):
        self._stage_timer.stop()
        if self.scanning:
            self.stop_scan()
        event.accept()
